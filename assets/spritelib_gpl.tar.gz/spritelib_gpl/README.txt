Sprites for use in the project.

The rest of the pictures
http://www.widgetworx.com/spritelib/



animales2_0.png
http://opengameart.org/content/fish-sprite-sheet
